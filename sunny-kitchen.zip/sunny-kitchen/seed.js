require('dotenv').config();
const mongoose = require('mongoose');
const MenuItem = require('./models/MenuItem');
const Offer = require('./models/Offer');

const menu = [
  // Starters
  { name: 'Paneer Tikka', category: 'Starters', description: 'Smoky tandoor-grilled paneer with peppers and mint chutney.', price: 220, veg: true, spice: 2, emoji: '🧀', popular: true },
  { name: 'Veg Spring Rolls', category: 'Starters', description: 'Crispy rolls stuffed with seasoned vegetables.', price: 160, veg: true, spice: 1, emoji: '🥟' },
  { name: 'Chicken 65', category: 'Starters', description: 'Spicy, crunchy South Indian fried chicken with curry leaves.', price: 240, veg: false, spice: 3, emoji: '🍗', popular: true },
  { name: 'Hara Bhara Kebab', category: 'Starters', description: 'Spinach and green pea patties, lightly pan-fried.', price: 180, veg: true, spice: 1, emoji: '🥬' },
  // Mains
  { name: 'Butter Chicken', category: 'Mains', description: 'Tender chicken in a rich, creamy tomato and butter gravy.', price: 320, veg: false, spice: 1, emoji: '🍛', popular: true },
  { name: 'Paneer Butter Masala', category: 'Mains', description: 'Soft paneer cubes in a velvety tomato-cashew gravy.', price: 280, veg: true, spice: 1, emoji: '🍲', popular: true },
  { name: 'Dal Tadka', category: 'Mains', description: 'Yellow lentils tempered with garlic, cumin and ghee.', price: 180, veg: true, spice: 1, emoji: '🥘' },
  { name: 'Chana Masala', category: 'Mains', description: 'Chickpeas simmered in a tangy, spiced onion-tomato masala.', price: 190, veg: true, spice: 2, emoji: '🫘' },
  { name: 'Kadai Chicken', category: 'Mains', description: 'Chicken cooked with bell peppers and freshly ground spices.', price: 310, veg: false, spice: 3, emoji: '🌶️' },
  { name: 'Palak Paneer', category: 'Mains', description: 'Paneer in a smooth, lightly spiced spinach gravy.', price: 260, veg: true, spice: 1, emoji: '🥗' },
  // Biryani
  { name: 'Veg Biryani', category: 'Biryani', description: 'Fragrant basmati layered with vegetables and whole spices. Served with raita.', price: 240, veg: true, spice: 2, emoji: '🍚' },
  { name: 'Chicken Biryani', category: 'Biryani', description: 'Slow-cooked dum biryani with juicy chicken. Served with raita.', price: 300, veg: false, spice: 2, emoji: '🍗', popular: true },
  { name: 'Egg Biryani', category: 'Biryani', description: 'Spiced basmati rice with masala-coated boiled eggs.', price: 250, veg: false, spice: 2, emoji: '🥚' },
  // Breads
  { name: 'Butter Naan', category: 'Breads', description: 'Soft tandoor-baked naan brushed with butter.', price: 55, veg: true, spice: 0, emoji: '🫓', popular: true },
  { name: 'Garlic Naan', category: 'Breads', description: 'Naan topped with fresh garlic and coriander.', price: 65, veg: true, spice: 0, emoji: '🧄' },
  { name: 'Tandoori Roti', category: 'Breads', description: 'Whole wheat roti baked in the tandoor.', price: 30, veg: true, spice: 0, emoji: '🍞' },
  // Desserts
  { name: 'Gulab Jamun', category: 'Desserts', description: 'Warm milk dumplings soaked in cardamom sugar syrup (2 pieces).', price: 90, veg: true, spice: 0, emoji: '🍮', popular: true },
  { name: 'Rasmalai', category: 'Desserts', description: 'Soft paneer discs in chilled saffron milk (2 pieces).', price: 110, veg: true, spice: 0, emoji: '🥛' },
  { name: 'Kulfi Falooda', category: 'Desserts', description: 'Traditional kulfi with falooda noodles and rose syrup.', price: 130, veg: true, spice: 0, emoji: '🍨' },
  // Drinks
  { name: 'Mango Lassi', category: 'Drinks', description: 'Thick, chilled yogurt drink blended with ripe mango.', price: 90, veg: true, spice: 0, emoji: '🥭', popular: true },
  { name: 'Masala Chai', category: 'Drinks', description: 'Hot tea simmered with ginger, cardamom and spices.', price: 40, veg: true, spice: 0, emoji: '☕' },
  { name: 'Fresh Lime Soda', category: 'Drinks', description: 'Sweet or salted, fizzy and refreshing.', price: 70, veg: true, spice: 0, emoji: '🍋' },
];

const inDays = (n) => new Date(Date.now() + n * 24 * 60 * 60 * 1000);

const offers = [
  { title: 'Welcome Sunny!', description: '20% off your first order, up to ₹150.', code: 'SUNNY20', discountPercent: 20, minOrder: 300, maxDiscount: 150, validTill: inDays(365) },
  { title: 'Family Feast', description: '15% off on orders above ₹800. Perfect for sharing.', code: 'FEAST15', discountPercent: 15, minOrder: 800, maxDiscount: 250, validTill: inDays(365) },
  { title: 'Weekend Treat', description: '10% off any order over ₹400, every weekend.', code: 'WEEKEND10', discountPercent: 10, minOrder: 400, maxDiscount: 100, validTill: inDays(365) },
];

async function run() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/sunny_kitchen');
  await MenuItem.deleteMany({});
  await Offer.deleteMany({});
  await MenuItem.insertMany(menu);
  await Offer.insertMany(offers);
  console.log(`Seeded ${menu.length} dishes and ${offers.length} offers.`);
  await mongoose.disconnect();
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
